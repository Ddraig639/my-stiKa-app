package com.tenzi.marck;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.firebase.FirebaseApp;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class OtherprofileActivity extends AppCompatActivity {
	
	private String SentString = "";
	private String ComingRequests = "";
	private boolean AddFriend = false;
	private boolean FriendRequest = false;
	private boolean RequestAccept = false;
	private HashMap<String, Object> map = new HashMap<>();
	private String UnfriendDialogTitle = "";
	private String UnfriendDialogMessage = "";
	private String YES = "";
	private String NO = "";
	private String AddFriendText = "";
	private String UnfriendText = "";
	private String AcceptRequestText = "";
	private String RequestSentText = "";
	
	private LinearLayout body;
	private CardView top;
	private LinearLayout nestedscroll;
	private LinearLayout top_;
	private ImageView back;
	private LinearLayout linear51;
	private ImageView message;
	private ImageView add;
	private ImageView cancel;
	private ImageView editpic;
	private ImageView logout;
	private ImageView menu;
	private LinearLayout nestedbody;
	private LinearLayout linear55;
	private CardView cardview1;
	private LinearLayout linear53;
	private LinearLayout more_tools;
	private LinearLayout buttons;
	private GridView image_post_view;
	private ImageView imageview2;
	private TextView title;
	private ImageView verified;
	private LinearLayout linear52;
	private LinearLayout info;
	private LinearLayout posts;
	private LinearLayout space;
	private LinearLayout friends;
	private TextView posts_title;
	private TextView posts_count;
	private TextView friends_title;
	private TextView friends_count;
	private TextView add_friend_button;
	private TextView message_button;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.otherprofile);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		body = findViewById(R.id.body);
		top = findViewById(R.id.top);
		nestedscroll = findViewById(R.id.nestedscroll);
		top_ = findViewById(R.id.top_);
		back = findViewById(R.id.back);
		linear51 = findViewById(R.id.linear51);
		message = findViewById(R.id.message);
		add = findViewById(R.id.add);
		cancel = findViewById(R.id.cancel);
		editpic = findViewById(R.id.editpic);
		logout = findViewById(R.id.logout);
		menu = findViewById(R.id.menu);
		nestedbody = findViewById(R.id.nestedbody);
		linear55 = findViewById(R.id.linear55);
		cardview1 = findViewById(R.id.cardview1);
		linear53 = findViewById(R.id.linear53);
		more_tools = findViewById(R.id.more_tools);
		buttons = findViewById(R.id.buttons);
		image_post_view = findViewById(R.id.image_post_view);
		imageview2 = findViewById(R.id.imageview2);
		title = findViewById(R.id.title);
		verified = findViewById(R.id.verified);
		linear52 = findViewById(R.id.linear52);
		info = findViewById(R.id.info);
		posts = findViewById(R.id.posts);
		space = findViewById(R.id.space);
		friends = findViewById(R.id.friends);
		posts_title = findViewById(R.id.posts_title);
		posts_count = findViewById(R.id.posts_count);
		friends_title = findViewById(R.id.friends_title);
		friends_count = findViewById(R.id.friends_count);
		add_friend_button = findViewById(R.id.add_friend_button);
		message_button = findViewById(R.id.message_button);
		
		add.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (RequestAccept) {
					map = new HashMap<>();
					map.put("sender", getIntent().getStringExtra("uid"));
					map.put("reciever", "");
					frs.child(getIntent().getStringExtra("uid").concat("/".concat(""))).updateChildren(map);
					map.clear();
					map = new HashMap<>();
					map.put("sender", "");
					map.put("reciever", getIntent().getStringExtra("uid"));
					frs.child("".concat("/".concat(getIntent().getStringExtra("uid")))).updateChildren(map);
					map.clear();
					ir.child(getIntent().getStringExtra("uid").concat("/".concat(""))).removeValue();
					ir.child("".concat("/".concat(getIntent().getStringExtra("uid")))).removeValue();
					fr.child(getIntent().getStringExtra("uid").concat("/".concat(""))).removeValue();
					fr.child("".concat("/".concat(getIntent().getStringExtra("uid")))).removeValue();
				}
				else {
					if (AddFriend) {
						
					}
					else {
						if (FriendRequest) {
							ir.child(getIntent().getStringExtra("uid").concat("/".concat(""))).removeValue();
							ir.child("".concat("/".concat(getIntent().getStringExtra("uid")))).removeValue();
							fr.child(getIntent().getStringExtra("uid").concat("/".concat(""))).removeValue();
							fr.child("".concat("/".concat(getIntent().getStringExtra("uid")))).removeValue();
						}
						else {
							map = new HashMap<>();
							map.put("sender", getIntent().getStringExtra("uid"));
							map.put("reciever", "");
							ir.child(getIntent().getStringExtra("uid").concat("/".concat(""))).updateChildren(map);
							map.clear();
							map = new HashMap<>();
							map.put("sender", "");
							map.put("reciever", getIntent().getStringExtra("uid"));
							fr.child("".concat("/".concat(getIntent().getStringExtra("uid")))).updateChildren(map);
							map.clear();
						}
					}
				}
			}
		});
	}
	
	private void initializeLogic() {
		SentString = "".concat("/".concat(getIntent().getStringExtra("uid")));
		ComingRequests = getIntent().getStringExtra("uid").concat("/".concat(""));
		AddFriend = false;
		FriendRequest = false;
		RequestAccept = false;
	}
	
	public void _it() {
		SentString = "".concat("/".concat(getIntent().getStringExtra("uid")));
		ComingRequests = getIntent().getStringExtra("uid").concat("/".concat(""));
		AddFriend = false;
		FriendRequest = false;
		RequestAccept = false;
		if (RequestAccept) {
			map = new HashMap<>();
			map.put("sender", getIntent().getStringExtra("uid"));
			map.put("reciever", "");
			frs.child(getIntent().getStringExtra("uid").concat("/".concat(""))).updateChildren(map);
			map.clear();
			map = new HashMap<>();
			map.put("sender", "");
			map.put("reciever", getIntent().getStringExtra("uid"));
			frs.child("".concat("/".concat(getIntent().getStringExtra("uid")))).updateChildren(map);
			map.clear();
			ir.child(getIntent().getStringExtra("uid").concat("/".concat(""))).removeValue();
			ir.child("".concat("/".concat(getIntent().getStringExtra("uid")))).removeValue();
			fr.child(getIntent().getStringExtra("uid").concat("/".concat(""))).removeValue();
			fr.child("".concat("/".concat(getIntent().getStringExtra("uid")))).removeValue();
		}
		else {
			if (AddFriend) {
				_NewCustomDialog(UnfriendDialogTitle, UnfriendDialogMessage, YES, NO, true);
			}
			else {
				if (FriendRequest) {
					ir.child(getIntent().getStringExtra("uid").concat("/".concat(""))).removeValue();
					ir.child("".concat("/".concat(getIntent().getStringExtra("uid")))).removeValue();
					fr.child(getIntent().getStringExtra("uid").concat("/".concat(""))).removeValue();
					fr.child("".concat("/".concat(getIntent().getStringExtra("uid")))).removeValue();
				}
				else {
					map = new HashMap<>();
					map.put("sender", getIntent().getStringExtra("uid"));
					map.put("reciever", "");
					ir.child(getIntent().getStringExtra("uid").concat("/".concat(""))).updateChildren(map);
					map.clear();
					map = new HashMap<>();
					map.put("sender", "");
					map.put("reciever", getIntent().getStringExtra("uid"));
					fr.child("".concat("/".concat(getIntent().getStringExtra("uid")))).updateChildren(map);
					map.clear();
				}
			}
		}
		if (_childKey.equals(getIntent().getStringExtra("uid"))) {
			add_friend_button.setText(AddFriendText);
			AddFriend = false;
			FriendRequest = false;
			_rippleRoundStroke(add_friend_button, "#651FFF", "#673AB7", 6, 0, "#FFFFFF");
		}
		if (_childKey.equals(getIntent().getStringExtra("uid"))) {
			add_friend_button.setText(AddFriendText);
			AddFriend = false;
			FriendRequest = false;
			_rippleRoundStroke(add_friend_button, "#651FFF", "#673AB7", 6, 0, "#FFFFFF");
		}
		if (_childKey.equals(getIntent().getStringExtra("uid"))) {
			add_friend_button.setText(UnfriendText);
			AddFriend = true;
			FriendRequest = false;
			_rippleRoundStroke(add_friend_button, "#FF1744", "#F44336", 6, 0, "#FFFFFF");
		}
		if (_childKey.equals(getIntent().getStringExtra("uid"))) {
			RequestAccept = true;
			add_friend_button.setText(AcceptRequestText);
			_rippleRoundStroke(add_friend_button, "#651FFF", "#673AB7", 6, 0, "#FFFFFF");
		}
		if (_childKey.equals(getIntent().getStringExtra("uid"))) {
			add_friend_button.setText(RequestSentText);
			AddFriend = false;
			FriendRequest = true;
			_rippleRoundStroke(add_friend_button, "#651FFF", "#673AB7", 6, 0, "#FFFFFF");
		}
	}
	
	public class Image_post_viewAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Image_post_viewAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.profile_image_post, null);
			}
			
			final androidx.cardview.widget.CardView body = _view.findViewById(R.id.body);
			final ImageView image = _view.findViewById(R.id.image);
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}