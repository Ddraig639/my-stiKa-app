package com.tenzi.marck;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import java.io.*;
import java.text.*;
import java.text.DecimalFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class ProfileActivity extends AppCompatActivity {
	
	public final int REQ_CD_PIC = 101;
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> user = new HashMap<>();
	private boolean RequestAccept = false;
	private HashMap<String, Object> map = new HashMap<>();
	private boolean AddFriend = false;
	private String UnfriendDialogTitle = "";
	private String UnfriendDialogMessage = "";
	private String YES = "";
	private String NO = "";
	private boolean FriendRequest = false;
	private String RequestSentText = "";
	private String AcceptRequestText = "";
	private String UnfriendText = "";
	private String AddFriendText = "";
	private double PcountN = 0;
	private double FcountN = 0;
	private String SentString = "";
	private String ComingRequests = "";
	private String OnlineStatus = "";
	private String OfflineStatus = "";
	private String ReportTitle = "";
	private String SettingsTitle = "";
	private String urlcopied = "";
	private String ProfileUrlTitle = "";
	private boolean d_user_accepted_your_request = false;
	private boolean u_accepted_d_user_request = false;
	private boolean d_user_sent_a_request = false;
	private boolean u_sent_the_user_a_request = false;
	private boolean d_user_is_friend = false;
	
	private ArrayList<String> pchildkeys = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> img_post = new ArrayList<>();
	
	private LinearLayout body;
	private CardView top;
	private LinearLayout nestedscroll;
	private LinearLayout top_;
	private ImageView back;
	private LinearLayout linear51;
	private ImageView message;
	private ImageView add;
	private ImageView cancel;
	private ImageView editpic;
	private ImageView logout;
	private ImageView menu;
	private LinearLayout nestedbody;
	private LinearLayout linear55;
	private CardView cardview1;
	private LinearLayout linear53;
	private LinearLayout more_tools;
	private LinearLayout buttons;
	private GridView image_post_view;
	private ImageView imageview2;
	private TextView title;
	private ImageView verified;
	private LinearLayout linear52;
	private LinearLayout info;
	private LinearLayout posts;
	private LinearLayout space;
	private LinearLayout friends;
	private TextView posts_title;
	private TextView posts_count;
	private TextView friends_title;
	private TextView friends_count;
	private TextView add_friend_button;
	private TextView message_button;
	
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private DatabaseReference udb = _firebase.getReference("user");
	private ChildEventListener _udb_child_listener;
	private Intent intprofile = new Intent();
	private AlertDialog.Builder logouter;
	private Intent out = new Intent();
	private Intent pic = new Intent(Intent.ACTION_GET_CONTENT);
	private Intent cropin = new Intent();
	private Intent crop = new Intent();
	private DatabaseReference fr = _firebase.getReference("frequest");
	private ChildEventListener _fr_child_listener;
	private DatabaseReference frs = _firebase.getReference("friends");
	private ChildEventListener _frs_child_listener;
	private DatabaseReference ir = _firebase.getReference("irequests");
	private ChildEventListener _ir_child_listener;
	private TimerTask timer;
	private DatabaseReference frMy = _firebase.getReference("frequest");
	private ChildEventListener _frMy_child_listener;
	private DatabaseReference irMy = _firebase.getReference("irequests");
	private ChildEventListener _irMy_child_listener;
	private DatabaseReference fc = _firebase.getReference("friends");
	private ChildEventListener _fc_child_listener;
	private DatabaseReference frsMy = _firebase.getReference("friends");
	private ChildEventListener _frsMy_child_listener;
	private DatabaseReference pdb = _firebase.getReference("posts");
	private ChildEventListener _pdb_child_listener;
	private AlertDialog.Builder asker;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.profile);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		body = findViewById(R.id.body);
		top = findViewById(R.id.top);
		nestedscroll = findViewById(R.id.nestedscroll);
		top_ = findViewById(R.id.top_);
		back = findViewById(R.id.back);
		linear51 = findViewById(R.id.linear51);
		message = findViewById(R.id.message);
		add = findViewById(R.id.add);
		cancel = findViewById(R.id.cancel);
		editpic = findViewById(R.id.editpic);
		logout = findViewById(R.id.logout);
		menu = findViewById(R.id.menu);
		nestedbody = findViewById(R.id.nestedbody);
		linear55 = findViewById(R.id.linear55);
		cardview1 = findViewById(R.id.cardview1);
		linear53 = findViewById(R.id.linear53);
		more_tools = findViewById(R.id.more_tools);
		buttons = findViewById(R.id.buttons);
		image_post_view = findViewById(R.id.image_post_view);
		imageview2 = findViewById(R.id.imageview2);
		title = findViewById(R.id.title);
		verified = findViewById(R.id.verified);
		linear52 = findViewById(R.id.linear52);
		info = findViewById(R.id.info);
		posts = findViewById(R.id.posts);
		space = findViewById(R.id.space);
		friends = findViewById(R.id.friends);
		posts_title = findViewById(R.id.posts_title);
		posts_count = findViewById(R.id.posts_count);
		friends_title = findViewById(R.id.friends_title);
		friends_count = findViewById(R.id.friends_count);
		add_friend_button = findViewById(R.id.add_friend_button);
		message_button = findViewById(R.id.message_button);
		auth = FirebaseAuth.getInstance();
		logouter = new AlertDialog.Builder(this);
		pic.setType("image/*");
		pic.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		asker = new AlertDialog.Builder(this);
		
		add.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (d_user_sent_a_request) {
					map = new HashMap<>();
					map.put("sender", getIntent().getStringExtra("uid"));
					map.put("reciever", FirebaseAuth.getInstance().getCurrentUser().getUid());
					frs.child(getIntent().getStringExtra("uid").concat("/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid()))).updateChildren(map);
					map.clear();
					map = new HashMap<>();
					map.put("sender", getIntent().getStringExtra("uid"));
					map.put("reciever", FirebaseAuth.getInstance().getCurrentUser().getUid());
					frs.child(FirebaseAuth.getInstance().getCurrentUser().getUid().concat("/".concat(getIntent().getStringExtra("uid")))).updateChildren(map);
					map.clear();
					fr.child(getIntent().getStringExtra("uid").concat("/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid()))).removeValue();
					ir.child(FirebaseAuth.getInstance().getCurrentUser().getUid().concat("/".concat(getIntent().getStringExtra("uid")))).removeValue();
					d_user_is_friend = true;
					d_user_accepted_your_request = true;
					u_accepted_d_user_request = true;
					u_sent_the_user_a_request = false;
					d_user_sent_a_request = false;
					cancel.setVisibility(View.VISIBLE);
					add.setImageResource(R.drawable.ic_seen);
					add.setColorFilter(0xFF5C6BC0, PorterDuff.Mode.MULTIPLY);
					timer = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									add.setImageResource(R.drawable.insta_20);
								}
							});
						}
					};
					_timer.schedule(timer, (int)(1000));
				}
				if (u_sent_the_user_a_request) {
					ir.child(getIntent().getStringExtra("uid").concat("/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid()))).removeValue();
					fr.child(FirebaseAuth.getInstance().getCurrentUser().getUid().concat("/".concat(getIntent().getStringExtra("uid")))).removeValue();
					d_user_is_friend = false;
					d_user_accepted_your_request = false;
					u_accepted_d_user_request = false;
					u_sent_the_user_a_request = false;
					d_user_sent_a_request = false;
					cancel.setVisibility(View.GONE);
					add.setImageResource(R.drawable.ic_seen);
					add.setColorFilter(0xFF5C6BC0, PorterDuff.Mode.MULTIPLY);
					timer = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									add.setImageResource(R.drawable.friends_list_icons_1);
								}
							});
						}
					};
					_timer.schedule(timer, (int)(1000));
				}
				if (d_user_is_friend || (u_accepted_d_user_request || d_user_accepted_your_request)) {
					asker.setTitle("Unfriend User");
					asker.setNegativeButton("Yes", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							d_user_is_friend = false;
							d_user_accepted_your_request = false;
							u_accepted_d_user_request = false;
							u_sent_the_user_a_request = false;
							d_user_sent_a_request = false;
							frs.child(getIntent().getStringExtra("uid").concat("/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid()))).removeValue();
							frs.child(FirebaseAuth.getInstance().getCurrentUser().getUid().concat("/".concat(getIntent().getStringExtra("uid")))).removeValue();
							cancel.setVisibility(View.GONE);
							add.setImageResource(R.drawable.ic_seen);
							add.setColorFilter(0xFF5C6BC0, PorterDuff.Mode.MULTIPLY);
							timer = new TimerTask() {
								@Override
								public void run() {
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											add.setImageResource(R.drawable.friends_list_icons_1);
										}
									});
								}
							};
							_timer.schedule(timer, (int)(1000));
						}
					});
					asker.setPositiveButton("No", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					asker.create().show();
				}
				if (!u_accepted_d_user_request && (!u_accepted_d_user_request && (!d_user_sent_a_request && (!u_sent_the_user_a_request && !d_user_is_friend)))) {
					map = new HashMap<>();
					map.put("sender", FirebaseAuth.getInstance().getCurrentUser().getUid());
					map.put("reciever", getIntent().getStringExtra("uid"));
					ir.child(getIntent().getStringExtra("uid").concat("/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid()))).updateChildren(map);
					map.clear();
					map = new HashMap<>();
					map.put("sender", FirebaseAuth.getInstance().getCurrentUser().getUid());
					map.put("reciever", getIntent().getStringExtra("uid"));
					fr.child(FirebaseAuth.getInstance().getCurrentUser().getUid().concat("/".concat(getIntent().getStringExtra("uid")))).updateChildren(map);
					map.clear();
					cancel.setVisibility(View.GONE);
					add.setImageResource(R.drawable.ic_seen);
					add.setColorFilter(0xFF5C6BC0, PorterDuff.Mode.MULTIPLY);
					timer = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									add.setImageResource(R.drawable.ic_highlight_remove_white);
									add.setColorFilter(0xFFEF5350, PorterDuff.Mode.MULTIPLY);
								}
							});
						}
					};
					_timer.schedule(timer, (int)(1000));
					d_user_is_friend = false;
					d_user_accepted_your_request = false;
					u_accepted_d_user_request = false;
					u_sent_the_user_a_request = true;
					d_user_sent_a_request = false;
				}
			}
		});
		
		cancel.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				if (d_user_sent_a_request) {
					fr.child(getIntent().getStringExtra("uid").concat("/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid()))).removeValue();
					ir.child(FirebaseAuth.getInstance().getCurrentUser().getUid().concat("/".concat(getIntent().getStringExtra("uid")))).removeValue();
					cancel.setVisibility(View.GONE);
					add.setImageResource(R.drawable.ic_seen);
					add.setColorFilter(0xFF5C6BC0, PorterDuff.Mode.MULTIPLY);
					timer = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									add.setImageResource(R.drawable.friends_list_icons_1);
								}
							});
						}
					};
					_timer.schedule(timer, (int)(1000));
				}
				return true;
			}
		});
		
		editpic.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(pic, REQ_CD_PIC);
			}
		});
		
		logout.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				logouter.setTitle("Log out?");
				logouter.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						FirebaseAuth.getInstance().signOut();
						out.setClass(getApplicationContext(), LoginActivity.class);
						startActivity(out);
						finish();
					}
				});
				logouter.setNegativeButton("No", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				logouter.create().show();
			}
		});
		
		_udb_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(getIntent().getStringExtra("uid"))) {
					if (getIntent().getStringExtra("uid").equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
						menu.setVisibility(View.VISIBLE);
						buttons.setVisibility(View.GONE);
						editpic.setVisibility(View.VISIBLE);
						logout.setVisibility(View.VISIBLE);
						add.setVisibility(View.GONE);
						message.setVisibility(View.GONE);
					}
					else {
						buttons.setVisibility(View.VISIBLE);
						menu.setVisibility(View.GONE);
						editpic.setVisibility(View.GONE);
						logout.setVisibility(View.GONE);
						add.setVisibility(View.VISIBLE);
						message.setVisibility(View.VISIBLE);
					}
					if (_childValue.containsKey("avatar")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("avatar").toString())).into(imageview2);
					}
					else {
						
					}
					title.setText("?".concat(_childValue.get("username").toString()));
					if (_childValue.get("verify").toString().equals("false")) {
						verified.setVisibility(View.GONE);
					}
					else {
						verified.setVisibility(View.VISIBLE);
					}
				}
				_telegramLoaderDialog(false);
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(getIntent().getStringExtra("uid"))) {
					if (_childValue.containsKey("avatar")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("avatar").toString())).into(imageview2);
					}
					else {
						
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		udb.addChildEventListener(_udb_child_listener);
		
		_fr_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		fr.addChildEventListener(_fr_child_listener);
		
		_frs_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		frs.addChildEventListener(_frs_child_listener);
		
		_ir_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		ir.addChildEventListener(_ir_child_listener);
		
		_frMy_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (true) {
						add.setImageResource(R.drawable.ic_highlight_remove_white);
						add.setColorFilter(0xFFEF5350, PorterDuff.Mode.MULTIPLY);
						_rippleRoundStroke(add_friend_button, "#651FFF", "#673AB7", 6, 0, "#FFFFFF");
						d_user_is_friend = false;
						d_user_accepted_your_request = false;
						u_accepted_d_user_request = false;
						u_sent_the_user_a_request = true;
						d_user_sent_a_request = false;
						add_friend_button.setText(RequestSentText);
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (d_user_is_friend) {
						
					}
					else {
						add.setImageResource(R.drawable.friends_list_icons_1);
						d_user_is_friend = false;
						d_user_accepted_your_request = false;
						u_accepted_d_user_request = false;
						u_sent_the_user_a_request = false;
						d_user_sent_a_request = false;
						_rippleRoundStroke(add_friend_button, "#651FFF", "#673AB7", 6, 0, "#FFFFFF");
						add_friend_button.setText(AddFriendText);
					}
				}
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		frMy.addChildEventListener(_frMy_child_listener);
		
		_irMy_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					d_user_is_friend = false;
					d_user_accepted_your_request = false;
					u_accepted_d_user_request = false;
					u_sent_the_user_a_request = false;
					d_user_sent_a_request = true;
					_rippleRoundStroke(add_friend_button, "#651FFF", "#673AB7", 6, 0, "#FFFFFF");
					add_friend_button.setText(AcceptRequestText);
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		irMy.addChildEventListener(_irMy_child_listener);
		
		_fc_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				FcountN++;
				_setCount(friends_count, FcountN);
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		fc.addChildEventListener(_fc_child_listener);
		
		_frsMy_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					add.setImageResource(R.drawable.insta_20);
					add.setColorFilter(0xFFEF9A9A, PorterDuff.Mode.MULTIPLY);
					d_user_is_friend = true;
					d_user_accepted_your_request = false;
					u_accepted_d_user_request = false;
					u_sent_the_user_a_request = false;
					d_user_sent_a_request = false;
					_rippleRoundStroke(add_friend_button, "#FF1744", "#F44336", 6, 0, "#FFFFFF");
					add_friend_button.setText(UnfriendText);
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					add.setImageResource(R.drawable.friends_list_icons_1);
					d_user_is_friend = false;
					d_user_accepted_your_request = false;
					u_accepted_d_user_request = false;
					u_sent_the_user_a_request = false;
					d_user_sent_a_request = false;
					_rippleRoundStroke(add_friend_button, "#651FFF", "#673AB7", 6, 0, "#FFFFFF");
					add_friend_button.setText(AddFriendText);
				}
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		frsMy.addChildEventListener(_frsMy_child_listener);
		
		_pdb_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childValue.get("post_key").toString().equals(_childValue.get("post_key").toString()) && _childValue.get("uid").toString().equals(getIntent().getStringExtra("uid"))) {
					pchildkeys.add(_childKey);
					PcountN++;
					_setCount(posts_count, PcountN);
					img_post.add(_childValue);
					image_post_view.setAdapter(new Image_post_viewAdapter(img_post));
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		pdb.addChildEventListener(_pdb_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		back.setVisibility(View.VISIBLE);
		body.setBackgroundColor(0xFFFFFFFF);
		title.setTextColor(0xFF000000);
		top_.setBackgroundColor(0xFFFFFFFF);
		posts_title.setTextColor(0xFF000000);
		friends_title.setTextColor(0xFF000000);
		posts_count.setTextColor(0xFF607D8B);
		friends_count.setTextColor(0xFF607D8B);
		cancel.setImageResource(R.drawable.ic_highlight_remove_white);
		cancel.setColorFilter(0xFFEF5350, PorterDuff.Mode.MULTIPLY);
		cancel.setVisibility(View.GONE);
		_rippleRoundStroke(add_friend_button, "#651FFF", "#673AB7", 6, 0, "#FFFFFF");
		_rippleRoundStroke(message_button, "#FFFFFF", "#CFD8DC", 6, 2, "#CFD8DC");
		SketchwareUtil.showMessage(getApplicationContext(), "crea");
		_telegramLoaderDialog(true);
		_setlayout(cardview1, SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 3, SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 3);
		SentString = FirebaseAuth.getInstance().getCurrentUser().getUid().concat("/".concat(getIntent().getStringExtra("uid")));
		ComingRequests = getIntent().getStringExtra("uid").concat("/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid()));
		AddFriend = false;
		FriendRequest = false;
		RequestAccept = false;
		YES = "Yes";
		NO = "No";
		OnlineStatus = "Active now";
		OfflineStatus = "Offline";
		RequestSentText = "Request Sent";
		AddFriendText = "Add Friend";
		AcceptRequestText = "Accept Request";
		UnfriendText = "Unfriend";
		ReportTitle = "Report";
		SettingsTitle = "Settings";
		urlcopied = "Profile Link Copied!";
		ProfileUrlTitle = "Share Profile";
		UnfriendDialogTitle = "INFO";
		UnfriendDialogMessage = "Are you sure you want to unfriend this user?";
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_PIC:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				crop.putExtra("url", _filePath.get((int)(0)));
				crop.setClass(getApplicationContext(), CropActivity.class);
				startActivity(crop);
				finish();
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		back.setVisibility(View.VISIBLE);
		body.setBackgroundColor(0xFFFFFFFF);
		title.setTextColor(0xFF000000);
		top_.setBackgroundColor(0xFFFFFFFF);
		posts_title.setTextColor(0xFF000000);
		friends_title.setTextColor(0xFF000000);
		posts_count.setTextColor(0xFF607D8B);
		friends_count.setTextColor(0xFF607D8B);
		_rippleRoundStroke(add_friend_button, "#651FFF", "#673AB7", 6, 0, "#FFFFFF");
		_rippleRoundStroke(message_button, "#FFFFFF", "#CFD8DC", 6, 2, "#CFD8DC");
		if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
			if (getIntent().getStringExtra("uid").equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
				buttons.setVisibility(View.GONE);
				message.setVisibility(View.GONE);
				add.setVisibility(View.GONE);
			}
			else {
				logout.setVisibility(View.GONE);
				menu.setVisibility(View.GONE);
				menu.setVisibility(View.GONE);
				message.setVisibility(View.VISIBLE);
				add.setVisibility(View.VISIBLE);
			}
		}
		else {
			
		}
	}
	
	@Override
	public void onBackPressed() {
		finish();
	}
	public void _telegramLoaderDialog(final boolean _visibility) {
		if (_visibility) {
			if (coreprog == null){
					coreprog = new ProgressDialog(this);
					coreprog.setCancelable(false);
					coreprog.setCanceledOnTouchOutside(false);
					
					coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE);  coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
					
			}
			coreprog.show();
			coreprog.setContentView(R.layout.loading);
			
			
			LinearLayout linear2 = (LinearLayout)coreprog.findViewById(R.id.linear2);
			
			LinearLayout back = (LinearLayout)coreprog.findViewById(R.id.background);
			
			LinearLayout layout_progress = (LinearLayout)coreprog.findViewById(R.id.layout_progress);
			
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(); 
			gd.setColor(Color.parseColor("#FFFFFF")); /* color */
			gd.setCornerRadius(45); /* radius */
			gd.setStroke(0, Color.WHITE); /* stroke heigth and color */
			linear2.setBackground(gd);
			
			RadialProgressView progress = new RadialProgressView(this);
			layout_progress.addView(progress);
			
		}
		else {
			if (coreprog != null){
				coreprog.dismiss();
			}
		}
	}
	private ProgressDialog coreprog;
	{
	}
	
	
	public void _rippleRoundStroke(final View _view, final String _focus, final String _pressed, final double _round, final double _stroke, final String _strokeclr) {
		android.graphics.drawable.GradientDrawable GG = new android.graphics.drawable.GradientDrawable();
		GG.setColor(Color.parseColor(_focus));
		GG.setCornerRadius((float)_round);
		GG.setStroke((int) _stroke,
		Color.parseColor("#" + _strokeclr.replace("#", "")));
		android.graphics.drawable.RippleDrawable RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.parseColor(_pressed)}), GG, null);
		_view.setBackground(RE);
	}
	
	
	public void _setlayout(final View _view, final double _width, final double _height) {
		_view.setLayoutParams(new LinearLayout.LayoutParams((int)_width, (int)_height));
	}
	
	
	public void _NewCustomDialog(final String _Title, final String _Message, final String _YesButtonText, final String _NoButtonText, final boolean _MultiButton) {
		final AlertDialog NewCustomDialog = new AlertDialog.Builder(ProfileActivity.this).create();
		LayoutInflater NewCustomDialogLI = getLayoutInflater();
		View NewCustomDialogCV = (View) NewCustomDialogLI.inflate(R.layout.new_custom_dialog, null);
		NewCustomDialog.setView(NewCustomDialogCV);
		NewCustomDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		final TextView dialog_title = (TextView)
		NewCustomDialogCV.findViewById(R.id.dialog_title);
		final TextView dialog_message = (TextView)
		NewCustomDialogCV.findViewById(R.id.dialog_message);
		final TextView dialog_no_button = (TextView)
		NewCustomDialogCV.findViewById(R.id.dialog_no_button);
		final TextView dialog_yes_button = (TextView)
		NewCustomDialogCV.findViewById(R.id.dialog_yes_button);
		_rippleRoundStroke(dialog_yes_button, "#651FFF", "#673AB7", 6, 0, "#FFFFFF");
		_rippleRoundStroke(dialog_no_button, "#FFFFFF", "#CFD8DC", 6, 2, "#CFD8DC");
		dialog_title.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/medium.ttf"), 1);
		dialog_title.setText(_Title);
		dialog_message.setText(_Message);
		if (_MultiButton) {
			dialog_no_button.setText(_NoButtonText);
			dialog_no_button.setVisibility(View.VISIBLE);
		}
		else {
			dialog_no_button.setVisibility(View.GONE);
		}
		dialog_yes_button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				frs.child(getIntent().getStringExtra("uid").concat("/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid()))).removeValue();
				frs.child(FirebaseAuth.getInstance().getCurrentUser().getUid().concat("/".concat(getIntent().getStringExtra("uid")))).removeValue();
				NewCustomDialog.dismiss();
				
			}
		});
		dialog_no_button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				NewCustomDialog.dismiss();
				
			}
		});
		dialog_yes_button.setText(_YesButtonText);
		NewCustomDialog.setCancelable(true);
		NewCustomDialog.show();
	}
	
	
	public void _setCount(final TextView _txt, final double _number) {
		_txt.setText(String.valueOf((long)(_number)));
		if (_number < 1000) {
			_txt.setText(String.valueOf((long)(_number)));
		}
		else {
			if (_number < 10000) {
				_txt.setText(String.valueOf(_number / 1000).substring((int)(0), (int)(3)).concat("K"));
			}
			else {
				if (_number < 100000) {
					_txt.setText(String.valueOf(_number / 1000).substring((int)(0), (int)(4)).concat("K"));
				}
				else {
					if (_number < 1000000) {
						_txt.setText(String.valueOf(_number / 1000).substring((int)(0), (int)(3)).concat("K"));
					}
					else {
						if (_number < 10000000) {
							_txt.setText(String.valueOf(_number / 1000000).substring((int)(0), (int)(3)).concat("M"));
						}
						else {
							if (_number < 100000000) {
								_txt.setText(String.valueOf(_number / 1000000).substring((int)(0), (int)(2)).concat("M"));
							}
							else {
								if (_number < 1000000000) {
									_txt.setText(String.valueOf(_number / 1000000).substring((int)(0), (int)(3)).concat("M"));
								}
								else {
									if (_number < 10000000000d) {
										_txt.setText(String.valueOf(_number / 1000000000).substring((int)(0), (int)(3)).concat("B"));
									}
									else {
										if (_number < 100000000000d) {
											_txt.setText(String.valueOf(_number / 1000000000).substring((int)(0), (int)(2)).concat("B"));
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	public class Image_post_viewAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Image_post_viewAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.profile_image_post, null);
			}
			
			final androidx.cardview.widget.CardView body = _view.findViewById(R.id.body);
			final ImageView image = _view.findViewById(R.id.image);
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}